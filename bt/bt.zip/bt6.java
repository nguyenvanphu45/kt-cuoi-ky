package bt;

public class bt6 {
    public static void main(String[] args) {
        String str1 = "hoc java co ban den nang cao.";
        String str2 = "java co ban";
        System.out.println(str1.contains(str2));
    }
}
